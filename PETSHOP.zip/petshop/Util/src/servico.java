import entidade.servico;

import java.util.Scanner;

public class servico {


    public static class Main {
        Scanner read = new Scanner(System.in);
        Servico servico = new Servico();
        Entidade.Servico entidadeServico = new Entidade.Servico();

        public void options() {
            char res;
            do {
                System.out.println("1 - Criar serviço");
                System.out.println("2 - Mostrar serviços");
                System.out.println("3 - Atualizar serviço");
                System.out.println("4 - Deletar serviço");
                System.out.println("");
                System.out.print("Digite uma opção: ");
                int option = Integer.parseInt(read.nextLine());

                switch (option) {
                    case 1:
                        System.out.println("Tipo do Serviço: ");
                        servico.setTipo(read.nextLine());
                        System.out.println("Valor do Serviço: ");
                        servico.setValor(Double.parseDouble(read.nextLine()));

                        entidadeServico.cadastrarServico(servico);
                        break;
                    case 2:
                        for (Servico servico : entidadeServico.getServicos()) {
                            System.out.println("ID: " + servico.getIdServico());
                            System.out.println("Tipo: " + servico.getTipo());
                            System.out.println("Valor: " + servico.getValor());
                        }
                        break;
                    case 3:
                        System.out.println("Deseja atualizar qual serviço? [ID]");
                        servico.setIdServico(read.nextInt());

                        System.out.println("Novo tipo: ");
                        servico.setTipo(read.nextLine());
                        System.out.println("Novo valor: ");
                        servico.setValor(Double.parseDouble(read.nextLine()));

                        entidadeServico.atualizarServico(servico);
                        break;
                    case 4:
                        System.out.println("Deseja Excluir qual serviço? [ID]");
                        int id = read.nextInt();

                        System.out.println("Tem certeza que deseja excluir o serviço? [s/n]");
                        char resp = read.nextLine().charAt(0);

                        if (resp == 's') {
                            entidadeServico.deletarServico(id);
                        } else {
                            System.out.println("Serviço não será excluído");
                        }
                        break;
                    default:
                        System.out.println("OPÇÃO INVÁLIDA");
                }

                System.out.println("Deseja Continuar? [S/N]");
                res = read.nextLine().charAt(0);
            } while (res != 'n');
        }

        public static void main(String[] args) {
            Main main = new Main();
            main.options();
        }
    }

}
