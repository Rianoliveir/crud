import entidade.animal;

import java.util.Scanner;
public class animal {


    public static class Main {
        Scanner read = new Scanner(System.in);
        animal animal = new Animal();
        Entidade.animal entidadeanimal = new Entidade.animal();

        public void options() {
            char res;
            do {
                System.out.println("1 - Criar animal");
                System.out.println("2 - Mostrar animais");
                System.out.println("3 - Atualizar animal");
                System.out.println("4 - Deletar animal");
                System.out.print("Digite uma opção: ");
                int option = Integer.parseInt(read.nextLine());

                switch (option) {
                    case 1:
                        System.out.println("Nome do Animal: ");
                        animal.setNome(read.nextLine());
                        System.out.println("Dono do Animal: ");
                        animal.setDono(read.nextLine());
                        System.out.println("raça do Animal: ");
                        animal.setDono(read.nextLine());
                        System.out.println("Serviço solicitado: ");
                        animal.setServico(Integer.parseInt(read.nextLine()));

                        entidadeanimal.cadastrarAnimal(animal);
                        break;
                    case 2:
                        for (animal animal : entidadeanimal.getAnimais()) {
                            System.out.println("ID: " + animal.getId_animal());
                            System.out.println("Nome: " + animal.getnome());
                            System.out.println("Dono: " + animal.getdono());
                            System.out.println("raça: " + animal.getraca());
                            System.out.println("Serviço: " + animal.getservico());
                            System.out.println("--------------------------------------------------------");
                        }
                        break;
                    case 3:
                        System.out.println("Deseja atualizar qual animal? [ID]");
                        animal.setIdAnimal(read.nextInt());

                        System.out.println("Novo nome: ");
                        animal.setNome(read.nextLine());
                        System.out.println("Novo dono: ");
                        animal.setDono(read.nextLine());
                        System.out.println("Novo serviço: ");
                        animal.setServico(Integer.parseInt(read.nextLine()));

                        entidadeanimal.atualizaranimal(animal);
                        break;
                    case 4:
                        System.out.println("Deseja Excluir qual animal? [ID]");
                        int id = read.nextInt();

                        System.out.println("Tem certeza que deseja excluir o animal? [s/n]");
                        char resp = read.nextLine().charAt(0);

                        if (resp == 's') {
                            entidadeanimal.deletaranimal(id);
                        } else {
                            System.out.println("Animal não será excluído");
                        }
                        break;
                    default:
                        System.out.println("OPÇÃO INVÁLIDA");
                }

                System.out.println("Deseja Continuar? [S/N]");
                res = read.nextLine().charAt(0);
            } while (res != 'n');
        }

        public static void main(String[] args) {
            Main main = new Main();
            main.options();
        }
    }

}
