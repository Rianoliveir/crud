import entidade.cliente.entidade.cliente;
import entidade.cliente;

import java.util.Scanner;
public class cliente {
    Scanner read = new Scanner(System.in);
    cliente cliente = new cliente();
    entidade.cliente entidade;.cliente = new entidade.cliente();
    public void options() {
        char res;
        do {
            System.out.println("1 - Criar cliente");
            System.out.println("2 - Mostrar clientes");
            System.out.println("3 - Atualizar cliente");
            System.out.println("4 - Deletar cliente");
            System.out.println("");
            System.out.print("Digite um opção: ");
            int option = Integer.parseInt(read.nextLine());


            switch (option) {
                case 1:
                    System.out.println("nome do cliente: ");
                    livro.setTitulo(read.nextLine());
                    System.out.println("animal do cliente: ");
                    livro.setAutor(read.nextLine());
                    System.out.println("servico solicitado: ");
                    livro.setAno_publicacao(Integer.parseInt(read.nextLine()));

                    entidadecliente.cadastrarcliente(cliente);
                    break;
                case 2:
                    for (cliente entidade.cliente : entidade.cliente.getcliente()) {
                        System.out.println("ID: " + entidade.cliente.getId_cliente());
                        System.out.println("nome: " + entidade.cliente.getnome());
                        System.out.println("animal: " + entidade.cliente.getanimal());
                        System.out.println("servico: " + entidade.cliente.getservico());
                        System.out.println("--------------------------------------------------------");

                    }
                    break;
                case 3:
                    System.out.println("Deseja atualizar qual cliente? [ID]");
                    cliente.setId_cliente(read.nextInt());

                    System.out.println("Novo nome: ");
                    cliente.setnome(read.nextLine());
                    System.out.println("Novo animal: ");
                    cliente.setanimal(read.nextLine());
                    System.out.println("Novo servico: ");
                    cliente.setservico(read.nextInt());

                    entidade.cliente.atualizarcliente(livro);
                    break;
                case 4:
                    System.out.println("Deseja Excluir qual cliente? [ID]");
                    int id = read.nextInt();

                    System.out.println("Tem certeza deseja exlcuir cliente? [s/n]");
                    char resp = read.nextLine().charAt(0);

                    if (resp == 's') {
                        entidade.cliente.deletarcliente(id);
                    } else {
                        System.out.println("cliente não será exluido");
                    }
                    break;
                default:
                    System.out.println("OPÇÃO INVALIDA");
            }

            System.out.println("Deseja Continuar? [S/N]");
            res = read.nextLine().charAt(0);
        } while (res != 'n');
    }
}
}
