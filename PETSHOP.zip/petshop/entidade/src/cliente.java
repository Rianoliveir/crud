public class cliente {
    private int id_cliente;
    private String nome;
    private String animal;
    private string servico;

    public cliente(){

    }

    public Livro(int id_cliente, String nome, String animal,string servico) {
        this.id_cliente = id_cliente;
        this.nome = nome;
        this.animal = animal;
        this.servico = servico;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public String getnome() {
        return nome;
    }

    public void setTitulo(String animal) {
        this.animal = animal;
    }

    public String getservico() {
        return servico;
    }

    public void setservico(String servico) {
        this.servico = servico;
    }


}
