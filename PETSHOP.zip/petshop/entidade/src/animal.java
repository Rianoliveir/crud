public class animal {
    public class Livro {
        private int id_animal;
        private String raca;
        private String dono;
        private string servico;

        private string nome;


        public Livro(){

        }

        public Livro(int id_animal, String raca, String dono, string servico,strring nome) {
            this.id_animal = id_animal;
            this.raca = raca;
            this.dono = dono;
            this.servico = servico;
            this.nome = nome;
        }

        public int getId_animal() {
            return id_animal;
        }

        public void setId_animal(int id_animal) {
            this.id_animal = id_animal;
        }

        public String getRaca() {
            return raca;
        }

        public void setRaca(String raca) {
            this.raca = raca;
        }

        public String getDono() {
            return dono;
        }

        public void setDono(String dono) {
            this.dono = dono;
        }

        public string getServico() {
            return servico;
        }

        public void setServico(string servico) {
            this.servico = servico;
        }
        public string nome() {
            return servico;
        }

        public void setnome(string nome) {
            this.nome = nome;
        }
    }

}
