public class servico {
    public class servico{
        private int id_servico;
        private String tipo;
        private String autor;
        private int valor;

        public servico() {

        }

        public servico (int id_servico, String tipo, String autor, int valor) {
            this.id_servico = id_servico;
            this.tipo = tipo;
            this.autor = autor;
            this.valor = valor;
        }

        public int getId_servico() {
            return id_servico;
        }

        public void setId_servico(int id_servico) {
            this.id_servico = id_servico;
        }

        public String getTipo() {
            return tipo;
        }

        public void setTipo(String tipo) {
            this.tipo = tipo;
        }

        public String getAutor() {
            return autor;
        }

        public void setAutor(String autor) {
            this.autor = autor;
        }

        public int getValor() {
            return valor;
        }

        public void setValor(int valor) {
            this.valor = valor;
        }
    }

}
