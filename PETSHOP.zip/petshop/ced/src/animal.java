import conexao.Conexao;
import entidadeanimal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
    public class animal {
        public void cadastraranimal ( animal  animal) {
            String sql = "INSERT INTO animal (nome, dono, raca,servico) VALUES (?,?,?,?)";

            Connection connection = null;
            PreparedStatement preparedStatement = null;

            try {
                connection = Conexao.createConnectionMYSQL();
                preparedStatement = connection.prepareStatement(sql);

                preparedStatement.setString(1, servico.getnome());
                preparedStatement.setString(2, servico.getDono());
                preparedStatement.setInt(3, servico.getraca());
                preparedStatement.setInt(3, servico.getservico());

                preparedStatement.execute();

                System.out.println("ANIMAL CADASTRADO COM SUCESSO");
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    if (connection != null) {
                        connection.close();
                    }

                    if (preparedStatement != null) {
                        preparedStatement.close();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }


    public void atualizaranimal( animal  animal){
        String sql = "UPDATE animal SET nome=?, dono=?, servico=?,raca=? WHERE id_animal=?";

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = Conexao.createConnectionMYSQL();
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setString(1, servico.getnome());
            preparedStatement.setString(2, servico.getDono());
            preparedStatement.setInt(3, servico.getraca());
            preparedStatement.setInt(4, servico.getservico());

            preparedStatement.setInt(5, servico.getId_animal());

            preparedStatement.execute();

            System.out.println("ANIMAL ATUALIZADO COM SUCESSO");

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void deletar animal(int id){
        String sql = "DELETE FROM servicos WHERE id_servico = ? ";

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = Conexao.createConnectionMYSQL();
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, id);

            preparedStatement.execute();

            System.out.println("ANIMAL DELETADO COM SUCESSO");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            try{
                if(preparedStatement != null){
                    preparedStatement.close();
                }

                if(connection != null){
                    connection.close();
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}

