import conexao.Conexao;
import entidade.cliente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
    public class cliente {
            public void cadastrarcliente ( cliente  cliente) {
                String sql = "INSERT INTO cliente (nome, animal,servico) VALUES (?,?,?)";

                Connection connection = null;
                PreparedStatement preparedStatement = null;

                try {
                    connection = Conexao.createConnectionMYSQL();
                    preparedStatement = connection.prepareStatement(sql);

                    preparedStatement.setString(1, servico.getnome());
                    preparedStatement.setString(2, servico.getanimal());
                    preparedStatement.setInt(3, servico.getservico());

                    preparedStatement.execute();

                    System.out.println("CLIENTE CADASTRADO COM SUCESSO");
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }

                        if (preparedStatement != null) {
                            preparedStatement.close();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

        }
        public void atualizarcliente( cliente  cliente){
            String sql = "UPDATE cliente SET animal=?, nome=?, servico=? WHERE id_cliente=?";

            Connection connection = null;
            PreparedStatement preparedStatement = null;

            try {
                connection = Conexao.createConnectionMYSQL();
                preparedStatement = connection.prepareStatement(sql);

                preparedStatement.setString(1, servico.getnome());
                preparedStatement.setString(2, servico.getanimal());
                preparedStatement.setInt(3, servico.getservico());

                preparedStatement.setInt(5, servico.getId_cliente());

                preparedStatement.execute();

                System.out.println("CLIENTE ATUALIZADO COM SUCESSO");

            }catch (Exception e){
                e.printStackTrace();
            }
        }

        public void deletarcliente(int id) throws RuntimeException {
            String sql = "DELETE FROM cliente WHERE id_clinte = ? ";

            Connection connection = null;
            PreparedStatement preparedStatement = null;

            try {
                connection = Conexao.createConnectionMYSQL();
                preparedStatement = connection.prepareStatement(sql);

                preparedStatement.setInt(1, id);

                preparedStatement.execute();

                System.out.println("CLIENTE DELETADO COM SUCESSO");
            } catch (SQLException e) {
                throw new RuntimeException(e);
            } finally {
                try{
                    if(preparedStatement != null){
                        preparedStatement.close();
                    }

                    if(connection != null){
                        connection.close();
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
    }


