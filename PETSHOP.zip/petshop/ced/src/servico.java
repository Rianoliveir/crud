import conexao.Conexao;
import entidade.servico;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
public class servico {
    public void cadastrarServico(Livro servico) {
        String sql = "INSERT INTO servicos (tipo, dono, valor) VALUES (?,?,?)";

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = Conexao.createConnectionMYSQL();
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setString(1, servico.getTipo());
            preparedStatement.setString(2, servico.getDono());
            preparedStatement.setInt(3, servico.getValor());

            preparedStatement.execute();

            System.out.println("SERVIÇO CADASTRADO COM SUCESSO");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}
    public void atualizarServico(servico servico){
        String sql = "UPDATE servicos SET tipo=?, dono=?, servico=? WHERE id_servico=?";

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = Conexao.createConnectionMYSQL();
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setString(1, servico.getTipo());
            preparedStatement.setString(2, servico.getDono());
            preparedStatement.setInt(3, servico.getValor());

            preparedStatement.setInt(4, servico.getId_servico());

            preparedStatement.execute();

            System.out.println("SERVIÇO ATUALIZADO COM SUCESSO");

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void deletarServico(int id){
        String sql = "DELETE FROM servicos WHERE id_servico = ? ";

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = Conexao.createConnectionMYSQL();
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, id);

            preparedStatement.execute();

            System.out.println("SERVIÇO DELETADO COM SUCESSO");
        }finally {
            try{
                if(preparedStatement != null){
                    preparedStatement.close();
                }

                if(connection != null){
                    connection.close();
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}
